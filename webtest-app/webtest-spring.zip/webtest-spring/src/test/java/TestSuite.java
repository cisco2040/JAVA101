import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.softtek.javaweb.service.UserServiceTest;


@RunWith(Suite.class)
@Suite.SuiteClasses({UserServiceTest.class})
public class TestSuite {

}

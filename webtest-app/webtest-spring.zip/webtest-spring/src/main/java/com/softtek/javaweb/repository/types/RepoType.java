package com.softtek.javaweb.repository.types;

public enum RepoType {
	CART,
	CITY,
	SHIPPING_ZONE,
	SHIP_TO,
	STATE,
	STATUS,
	USER,
	USER_ROLE
}

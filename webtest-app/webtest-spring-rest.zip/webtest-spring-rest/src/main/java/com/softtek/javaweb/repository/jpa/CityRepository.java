package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.City;

public interface CityRepository extends BaseRepository<City, Long> {

}

package com.softtek.javaweb.service.types;

public enum UpdateType {
	NEW,
	MODIFY
}

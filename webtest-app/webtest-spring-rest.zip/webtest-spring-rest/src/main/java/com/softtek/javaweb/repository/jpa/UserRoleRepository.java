package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.UserRole;

public interface UserRoleRepository extends BaseRepository<UserRole, String> {

}

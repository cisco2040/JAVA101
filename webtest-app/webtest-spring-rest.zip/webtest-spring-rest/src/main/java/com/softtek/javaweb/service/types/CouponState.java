package com.softtek.javaweb.service.types;

public enum CouponState {
	VALID, NON_EXISTENT, NOT_ACTIVE, EXPIRED, REDEEMED; 
}

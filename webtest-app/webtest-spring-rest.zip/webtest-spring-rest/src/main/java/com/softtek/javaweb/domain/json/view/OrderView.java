package com.softtek.javaweb.domain.json.view;

public class OrderView {
	public static class Public {}
	public static class Internal extends Public {}
	private OrderView() {}
}

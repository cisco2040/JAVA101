package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.State;

public interface StateRepository extends BaseRepository<State, Long> {

}

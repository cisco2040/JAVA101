package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.Status;

public interface StatusRepository extends BaseRepository<Status, Long> {

}

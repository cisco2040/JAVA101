package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.User;

public interface UserRepository extends BaseRepository<User, String> {

}

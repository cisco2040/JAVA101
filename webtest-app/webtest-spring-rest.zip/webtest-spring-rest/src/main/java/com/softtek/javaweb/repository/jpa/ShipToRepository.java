package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.ShipTo;

public interface ShipToRepository extends BaseRepository<ShipTo, Long> {

}

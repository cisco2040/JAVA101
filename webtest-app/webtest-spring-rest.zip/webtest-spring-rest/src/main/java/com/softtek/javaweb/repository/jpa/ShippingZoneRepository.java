package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.ShippingZone;

public interface ShippingZoneRepository extends BaseRepository<ShippingZone, String> {

}

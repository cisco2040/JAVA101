package com.softtek.javaweb.repository.jpa;

import com.softtek.javaweb.domain.model.PaymentMethod;

public interface PaymentMethodRepository extends BaseRepository<PaymentMethod, String> {
}

package com.softtek.java.academy.basics.enums;

public class MonthsStaticsUtil {

	static final String JAN = "January";
	static final String FEB = "February";
	static final String MAR = "March";
	static final String APR = "April";
	static final String MAY = "May";
	static final String JUN = "June";
	static final String JUL = "July";
	static final String AUG = "August";
	static final String SEP = "September";
	static final String OCT = "October";
	static final String NOV = "November";
	static final String DEC = "December";
}

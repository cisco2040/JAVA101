package com.softtek.java.academy.basics.conditionals;


public class PositiveNumber {
	public boolean isPositiveNumber(int num){
		if(num<0){
			return false;
		}else{
			return true;
		}
	}
}

package com.softtek.java.academy.basics.interfaces;

public interface Figurable {

	double getArea();
}

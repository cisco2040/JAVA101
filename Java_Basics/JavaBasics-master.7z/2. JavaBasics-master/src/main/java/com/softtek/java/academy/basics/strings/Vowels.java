package com.softtek.java.academy.basics.strings;

public class Vowels {

	public boolean isVowel(final String c) {

		return c.contains("a")
				|| c.contains("A")
				|| c.contains("e")
				|| c.contains("E")
				|| c.contains("i")
				|| c.contains("I")
				|| c.contains("o")
				|| c.contains("O")
				|| c.contains("u")
				|| c.contains("U");
	}

	public String getVowels(final String s) {

		final StringBuffer sb = new StringBuffer();
		s.toCharArray();

		return null;
	}
}

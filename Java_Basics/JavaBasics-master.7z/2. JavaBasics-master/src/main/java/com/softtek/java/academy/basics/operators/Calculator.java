package com.softtek.java.academy.basics.operators;

public class Calculator {

	public int getSum(final int n1, final int n2) {

		return n1 + n2;
	}

	public int getRest(final int n1, final int n2) {

		return n1 - n2;
	}

	public int getMult(final int n1, final int n2) {

		return n1 * n2;
	}

	public boolean isPositive(int n) {

		return n > 0;
	}

	public int getDiv(final int n1, final int n2) {

		return n1 / n2;
	}

	public int getMod(final int n1, final int n2) {

		return n1 % n2;
	}

}

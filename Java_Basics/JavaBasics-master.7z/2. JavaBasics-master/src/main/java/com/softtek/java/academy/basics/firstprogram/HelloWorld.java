/**
 * 
 */
package com.softtek.java.academy.basics.firstprogram;

/**
 * This class will show to the student how to create a hello world in java
 * @author Koitoer
 *
 */
public class HelloWorld {

	/**
	 * Main method and its signature
	 * @param args
	 */
	public static void main(final String[] args) {

		System.out.println("Hello World Java");
	}

}

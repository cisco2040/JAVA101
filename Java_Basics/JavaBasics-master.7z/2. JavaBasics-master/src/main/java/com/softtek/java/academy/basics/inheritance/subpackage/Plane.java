package com.softtek.java.academy.basics.inheritance.subpackage;

import com.softtek.java.academy.basics.inheritance.Transport;

public class Plane extends Transport {

	public Plane() {

		anotherAttr = "";
		ruta = "";
		go();
	}
}

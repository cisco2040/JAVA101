package com.softtek.java.academy.basics.enums;

public enum MonthsEnum {
	JANUARY,
	FEBRUARY,
	MARCH,
	APRIL,
	MAY,
	JUN,
	JULY,
	AUGUST,
	SEPTEMBER,
	OCTOBER,
	NOVEMBER,
	DECEMBER
}

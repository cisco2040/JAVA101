package com.softtek.java.academy.basics.arrays;

public class ArraysExample {

	/**
	 * @param args
	 */
	public static void main(final String[] args) {

		final int[] nums = { 3, 4, 5, 6, 2 };

		final PrintArrays ar = new PrintArrays();

		System.out.println(ar.printArray(nums));

	}

}

# JavaBasics
Java Basic course for Sofftek Java Academy
